package com.javatechie.user.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUserExample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
