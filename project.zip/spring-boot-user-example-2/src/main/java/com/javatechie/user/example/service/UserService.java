package com.javatechie.user.example.service;

import com.javatechie.user.example.entity.User;
import com.javatechie.user.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class UserService {
	 @Autowired
	    private UserRepository repository;

	 public User saveProduct(User user) {
	        return repository.save(user);
	    }

	    public List<User> saveProducts(List<User> users) {
	        return repository.saveAll(users);
	    }

	    public List<User> getusers() {
	        return repository.findAll();
	    }

	    public User getUserById(int id) {
	        return repository.findById(id).orElse(null);
	    }

	    public User getUserByName(String name) {
	        return repository.findByName(name);
	    }

	    public String deleteUser(int id) {
	        repository.deleteById(id);
	        return "user removed !! " + id;
	    }

	    public User updateUser(User user) {
	        User existingUser = repository.findById(user.getId()).orElse(null);
	        existingUser.setUname(user.getUname());
	        existingUser.setPassword(user.getPassword());
	        existingUser.setFirstname(user.getFirstname());
	        existingUser.setLastname(user.getLastname());
	        
	        return repository.save(existingUser);
	    }

		public User saveUser(User user) {
			// TODO Auto-generated method stub
			return null;
		}

		public List<User> saveUsers(List<User> users) {
			// TODO Auto-generated method stub
			return null;
		}

		public List<User> getUsers() {
			// TODO Auto-generated method stub
			return null;
		}


	}

