package com.javatechie.user.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUserExample2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUserExample2Application.class, args);
	}

}
